﻿using System;
using System.Collections.Generic;

namespace Projet_Examen.Models
{
    public partial class Options
    {
        public Options()
        {
            Answer = new HashSet<Answer>();
        }

        public int OptionId { get; set; }
        public string Text { get; set; }
        public bool IsRight { get; set; }
        public int? QuestionId { get; set; }

        public virtual Question Question { get; set; }
        public virtual ICollection<Answer> Answer { get; set; }
    }
}
