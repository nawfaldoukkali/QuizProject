﻿using System;
using System.Collections.Generic;

namespace Projet_Examen.Models
{
    public partial class Question
    {
        public Question()
        {
            Options = new HashSet<Options>();
            QuestionQuiz = new HashSet<QuestionQuiz>();
        }

        public int QuestionId { get; set; }
        public string Text { get; set; }
        public int? CategoryId { get; set; }

        public virtual Category Category { get; set; }
        public virtual ICollection<Options> Options { get; set; }
        public virtual ICollection<QuestionQuiz> QuestionQuiz { get; set; }
    }
}
