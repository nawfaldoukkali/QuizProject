﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Projet_Examen.Models;

namespace Projet_Examen.Controllers
{
    public class HomeController : Controller
    {
        private readonly QuizExamenContext db;



        //QuizExamenContext db = new QuizExamenContext();
        public HomeController(QuizExamenContext db)
        {
            this.db = db;
        }


        public IActionResult Index()
        {
            return View(db.Category);
        }

        public IActionResult CreerNouveauQuiz()
        {
            return View();
        }

        //1- Ajouter un quiz et ses questions et afficher la page pour le passer
        public IActionResult ListeDesQuestions(int CategoryId_Easy, int nbr_Question_Easy, int CategoryId_Medium, int nbr_Question_Medium, int CategoryId_Hard, int nbr_Question_Hard,int QuestionId, String UserName, String Email)
        {  
            var Easy_questions   = db.Question.Where(c => c.CategoryId == CategoryId_Easy).ToList().Take(nbr_Question_Easy);
            var Medium_questions = db.Question.Where(c => c.CategoryId == CategoryId_Medium).ToList().Take(nbr_Question_Medium);
            var Hard_questions   = db.Question.Where(c => c.CategoryId == CategoryId_Hard).ToList().Take(nbr_Question_Hard);
            var Quiz_Questions   = Easy_questions.Concat(Medium_questions).Concat(Hard_questions).ToList();

            //** Ajouter un QuizID sur la table : QUIZ ** //
            Quiz CreationNewQuiz = new Quiz();
            CreationNewQuiz.UserName = UserName;
            CreationNewQuiz.Email = Email;
            db.Add<Quiz>(CreationNewQuiz);
            db.SaveChanges();

            //** Ajouter les questions et iD quizz sur la table : QuestionQuiz **/
            QuestionQuiz CreationQuestionQuiz = new QuestionQuiz();
            foreach (var Ques in Quiz_Questions)
            {
                CreationQuestionQuiz.QuestionId = Ques.QuestionId;
                CreationQuestionQuiz.QuizId = CreationNewQuiz.QuizId;
                db.Add<QuestionQuiz>(CreationQuestionQuiz);
                db.SaveChanges();
            }

            return View(Quiz_Questions);
        }

        //2- Ajouter un quiz et ses questions SANS afficher la page pour le passer
            public IActionResult Ajouter_New_Quiz(int CategoryId_Easy, int nbr_Question_Easy, int CategoryId_Medium, int nbr_Question_Medium, int CategoryId_Hard, int nbr_Question_Hard,int QuestionId, String UserName, String Email)

            {
                var Easy_questions = db.Question.Where(c => c.CategoryId == CategoryId_Easy).ToList().Take(nbr_Question_Easy);
                var Medium_questions = db.Question.Where(c => c.CategoryId == CategoryId_Medium).ToList().Take(nbr_Question_Medium);
                var Hard_questions = db.Question.Where(c => c.CategoryId == CategoryId_Hard).ToList().Take(nbr_Question_Hard);
                var Quiz_Questions = Easy_questions.Concat(Medium_questions).Concat(Hard_questions).ToList();

                //Ajouter un QuizID sur la table : QUIZ
                Quiz CreationNewQuiz = new Quiz();
                CreationNewQuiz.UserName = UserName;
                CreationNewQuiz.Email = Email;
                db.Add<Quiz>(CreationNewQuiz);
                db.SaveChanges();

                //Ajouter les questions et iD quizz sur la table : QuestionQuiz
                QuestionQuiz CreationQuestionQuiz = new QuestionQuiz();
                foreach (var Ques in Quiz_Questions)
                {
                    CreationQuestionQuiz.QuestionId = Ques.QuestionId;
                    CreationQuestionQuiz.QuizId = CreationNewQuiz.QuizId;
                    db.Add<QuestionQuiz>(CreationQuestionQuiz);
                    db.SaveChanges();
                }

                return View("Index");
            }
        

         //3 - Afficher la ListeDesQuiz d'un utilisateur saisit
            public IActionResult ListeDesQuiz(String UserName, String Email)
            {
                var ListeQuiz = db.Quiz.Where(c => c.UserName == UserName && c.Email == Email).ToList();
                ViewBag.FN = db.Quiz.Where(c => c.UserName == UserName && c.Email == Email).ToList();
                ViewBag.uname = UserName;
                ViewBag.email = Email;
                return View(ListeQuiz);

            }

        //4 - Passer un Quizz et afficher les questions
        public IActionResult PasserQuiz(int QuizId)
        {
            var chargerLesQuestions = db.QuestionQuiz.Where(c => c.QuizId == QuizId).ToList();
            ViewBag.QuizId = QuizId;
            return View(chargerLesQuestions);
        }

        //5 - Soumettre un Quizz 
        public IActionResult SoumettreQuiz(int QuizId)
        {
            var i = 0;
            foreach (var key in HttpContext.Request.Query.Keys)

            {
                StringValues someInt;
                HttpContext.Request.Query.TryGetValue(key, out someInt);
                //Debug.WriteLine(someInt);

                if (i > 0)
                {
                Answer AjouterUneReponse = new Answer();

                AjouterUneReponse.QuizId = QuizId;
                AjouterUneReponse.OptionId = int.Parse(someInt);
                db.Add<Answer>(AjouterUneReponse);
                
                    db.SaveChanges();
                }
                i = i + 1;
            }

            return RedirectToAction ("Index");

        }


        //6 - Afficher la Liste des Quiz passé par un utilisateur
        public IActionResult ListeDesQuiz_A_reviser(String UserName, String Email)
        {
            var Reviser_ListeQuiz = db.Quiz.Where(c => c.UserName == UserName && c.Email == Email && c.Answer.Count > 0).ToList();
            ViewBag.uname = UserName;
            ViewBag.email = Email;
            return View(Reviser_ListeQuiz);

        }

        //7 - Afficher La révision d'un quizz
        public IActionResult ReviserQuiz(int QuizId, String UserName)
        {
            var chargerLesQuestions = db.QuestionQuiz.Where(c => c.QuizId == QuizId).ToList();
            ViewBag.QuizId = QuizId;
            ViewBag.uname = UserName;
            return View(chargerLesQuestions);
        }




    }
    }
